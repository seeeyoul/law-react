export const SET_SETTING_NUM = "Control/SET_SETTING_NUM";
export const SET_CASE_TYPE = "Control/SET_CASE_TYPE";
