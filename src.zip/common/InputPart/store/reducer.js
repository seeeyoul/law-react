//import {fromJS} from "immutable";
import * as constants from "./constants";
const defaultState = {
    upload:false,
    data:[],
    csv: false
};

export default (state = defaultState,action) => {
    switch (action.type) {
        case constants.BLACKBOX_CLASSIFY_UPLOAD:
            return {
                ...state,
                upload: true,
                data: action.res,
                csv: false
            };
        case constants.BLACKBOX_CSV:
            return {
                ...state,
                upload: false,
                data: action.res,
                csv: true
            };
        case constants.CLOSE_CSV:
            return {
                ...state,
                upload: true,
                csv: false
            };
        default:
            return state;
    }
}
