import React,{PureComponent} from "react";

class WhiteboxClassify extends PureComponent{
    render() {
        return (
            <div>

            </div>
        );
    }
}

export default WhiteboxClassify
