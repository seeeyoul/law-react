import React from 'react';

const Map = (props) => {
    return (
        <div className='row-spacebetween-start'>
            <div className='left'>
                <label>实体关系图</label>
            </div>
            <div style={{
                width:'calc(100vw - 556px)',
                minHeight:'300px',
                marginTop:'20px',
                border:'1px dashed #d9d9d9'
            }}>

            </div>
        </div>
    )
};

export default Map;
