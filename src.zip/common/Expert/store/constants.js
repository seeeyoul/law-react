export const EXPERT_SAVE = "Blackbox/EXPERT_SAVE";
export const SAVE_SUCCESS = "Blackbox/SAVE_SUCCESS";
export const SAVE_FAILED = "Blackbox/SAVE_FAILED";
