import React,{PureComponent} from "react";

class WhiteboxKnowledge extends PureComponent{
    render() {
        return (
            <div>

            </div>
        );
    }
}

export default WhiteboxKnowledge
