export const BLACKBOX_CLASSIFY_UPLOAD = "Blackbox/BLACKBOX_CLASSIFY_UPLOAD";
export const BLACKBOX_CSV = "Blackbox/BLACKBOX_CSV";
export const CLOSE_CSV = "Blackbox/CLOSE_CSV";
