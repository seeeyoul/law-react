self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "05549228e6d44aa3d74f277814203aa6",
    "url": "./index.html"
  },
  {
    "revision": "859d443de4d3ccfd0f07",
    "url": "./static/css/2.7c2c7a7e.chunk.css"
  },
  {
    "revision": "d9c5f2aba5d6e5ab2908",
    "url": "./static/css/main.5becd8ad.chunk.css"
  },
  {
    "revision": "859d443de4d3ccfd0f07",
    "url": "./static/js/2.3505d296.chunk.js"
  },
  {
    "revision": "d9c5f2aba5d6e5ab2908",
    "url": "./static/js/main.ce544054.chunk.js"
  },
  {
    "revision": "8c97409f0ee389fe75da",
    "url": "./static/js/runtime~main.d653cc00.js"
  },
  {
    "revision": "98b0e6e5100e006d7e3430b9d4bc65f6",
    "url": "./static/media/logo.98b0e6e5.png"
  }
]);